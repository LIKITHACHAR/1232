from django.urls import path, include
from ms_identity_web.django.msal_views_and_urls import MsalViews
from django.conf import settings



from transaction.views import *
msal_urls = MsalViews(settings.MS_IDENTITY_WEB).url_patterns()

urlpatterns = [
    # path('', home, name = "Home"),
    path('', index, name = "index"),
    path('transaction/add', addtransaction, name = "Add Share"),
    path('transaction/transfer', transfer, name = "Add Transfer"),
    path('transaction/convert', convert, name = "Add Conversion"),
    path('addsh', addshareholder, name = "Add Shareholder"),
    path('addtr', addtransaction, name = "Add Transaction"),
    path('transaction', transaction, name="Transaction"),
    path('generate', generate, name = "Generate Report"),
    path('company', company, name = "company"),
    path('addcomp', addcompany , name = "Add Company")
    # path(f'{settings.AAD_CONFIG.django.auth_endpoints.prefix}/', include(msal_urls))
]