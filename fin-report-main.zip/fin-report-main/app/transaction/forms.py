from django import  forms

from core.models import (
    ShareHolder,
    Transaction,
    Company
)

share_classes = [
                    ('Ordinary', 'Ordinary Shares'),
                    ('A', 'A'),
                    ('B', 'B'),
                    ('C', 'C')
                ]

Currency = [
                ('₹','₹ Rs'),('€','€ EUR'),('$','$ USD') ,('£','£ GBP'),('₣','₣ CHF')    
]

def get_folio():
    return [(f.folio_no, str(f)) for f in ShareHolder.objects.all()]

def get_comp():
    return [(f.name, str(f)) for f in Company.objects.all()]

class AddShareholderForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for visible in self.visible_fields():
            visible.field.widget.attrs['class'] = 'form-control'
        self.fields['name'].widget.attrs.update({'required': '', 'name': 'sh_name', 'id': 'sh_name', 'type': 'text'})
        self.fields['address'].widget.attrs.update({'required': '', 'name': 'sh_address', 'id': 'sh_address', 'type': 'textarea', 'rows': '4'})
        self.fields['legal_form'].widget.attrs.update({'required': '', 'name': 'sh_lf', 'id': 'sh_lf', 'type': 'textarea', 'rows': '4'})

    class Meta:
        model = ShareHolder
        fields = ['name', 'address', 'legal_form']

class AddcompanyForm(forms.Form):
    name = forms.CharField(max_length=255)
    address = forms.CharField(max_length=10000)
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for visible in self.visible_fields():
            visible.field.widget.attrs['class'] = 'form-control' 
        #self.fields['name'] = forms.ChoiceField(choices=get_comp)    
        self.fields['name'].widget.attrs.update({'required': '', 'name': 'cp_name', 'id': 'cp_name', 'type': 'text'})
        self.fields['address'].widget.attrs.update({'required': '', 'name': 'cp_address', 'id': 'cp_address', 'type': 'textarea', 'rows': '4'})
        self.fields['currency'] = forms.ChoiceField(choices=Currency)
        self.fields['currency'].widget.attrs.update({'required': '', 'name': 'currency', 'id': 'currency', 'class': 'form-select'})

    class Meta:
        #model = Company
        fields = ['name', 'address']

class AddTransactionForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for visible in self.visible_fields():
            visible.field.widget.attrs['class'] = 'form-control'
        self.fields['folio_no'] = forms.ChoiceField(choices=get_folio)
        self.fields['folio_no'].widget.attrs.update({'required': '', 'name': 'folio_no', 'id': 'folio_no', 'class': 'form-select'})
        self.fields['event'].widget.attrs.update({'required': '', 'name': 'event', 'id': 'event', 'class': 'form-select'})
        self.fields['no_of_shares'].widget.attrs.update({'required': '', 'name': 'no_of_shares', 'id': 'no_of_shares', 'type': 'number', 'step': 'any'})
        self.fields['nominal_value'].widget.attrs.update({'required': '', 'name': 'nominal_value', 'id': 'nominal_value', 'type': 'number', 'step': 'any'})
        self.fields['consideration'].widget.attrs.update({'required': '', 'name': 'consideration', 'id': 'consideration', 'type': 'number', 'step': 'any'})
        self.fields['total'].widget.attrs.update({'required': '', 'name': 'total', 'id': 'total', 'type': 'number', 'step': 'any'})
        self.fields['status'].widget.attrs.update({'type': 'hidden', 'name': 'status', 'id': 'status', 'value': 'Active'})
        self.fields['event_date'] = forms.DateField(widget=forms.TextInput(attrs={'name': 'event_date', 'id': 'event_date','class': 'form-control', 'type':'date'}))
        # self.fields['event_date'].widget.attrs.update({'type': 'date', 'name': 'event_date', 'id': 'event_date'})
        self.fields['class_of_share'] = forms.ChoiceField(choices=share_classes)
        self.fields['class_of_share'].widget.attrs.update({'required': '', 'name': 'class_of_share', 'id': 'class_of_share', 'class': 'form-select'})

    class Meta:
        model = Transaction
        fields = ['folio_no', 'event', 'no_of_shares', 'nominal_value', 'consideration', 'total', 'status']
        extra_fields = ['class_of_share', 'event_date']

class TransferShareForm(forms.Form):
    event = forms.CharField(max_length=255)
    no_of_shares = forms.DecimalField(max_digits=15, decimal_places=2)
    nominal_value = forms.DecimalField(max_digits=15, decimal_places=2, initial=0.01)
    consideration = forms.DecimalField(max_digits=15, decimal_places=2)
    event_date = forms.DateField(widget=forms.TextInput(attrs={'class': 'form-control', 'type':'date'}))
    transferer = forms.ChoiceField(choices=get_folio)
    transferee = forms.ChoiceField(choices=get_folio)
    share_class = forms.ChoiceField(choices=share_classes)
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for visible in self.visible_fields():
            visible.field.widget.attrs['class'] = 'form-control'
            # self.fields['event_date'].widget.attrs.update({'type': 'Date'})

class ConversionShareForm(forms.Form):
    folio_no = forms.ChoiceField(choices=get_folio)
    event_date = forms.DateField(widget=forms.TextInput(attrs={'class': 'form-control', 'type':'date'}))
    share_class = forms.ChoiceField(choices=share_classes)
    convert_class = forms.ChoiceField(choices=share_classes)
    convert_quantity = forms.DecimalField(max_digits=15, decimal_places=2)
    consideration = forms.DecimalField(max_digits=15, decimal_places=2)
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for visible in self.visible_fields():
            visible.field.widget.attrs['class'] = 'form-control'
