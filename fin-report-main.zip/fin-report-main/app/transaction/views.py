from django.shortcuts import render, redirect
from django.contrib import messages
from django.shortcuts import get_object_or_404
from django.http import HttpResponse , StreamingHttpResponse
from wsgiref.util import FileWrapper
# from ms_identity_web import MSALApp
import mimetypes 
import os
from django.conf import settings
from core.models import (
    Transaction,
    ShareHolder,
    Shares,
    TransferDetails,
    ConvertDetails,
    Company
)

ms_identity_web = settings.MS_IDENTITY_WEB
from core.utils import (
    generate_header,
    generate_row,
    generate_frontpage
)

from transaction.forms import (
    AddShareholderForm,
    AddTransactionForm,
    TransferShareForm,
    ConversionShareForm,
    AddcompanyForm
)

import datetime
import openpyxl

def index(request):
    
    data = Transaction.objects.all()
    args = {}
    args['data'] = data
    return render(request, 'transactionview.html', args)

@ms_identity_web.login_required
def update_shares(folio_no, share_class, no_of_shares):
    try:
        print('A', share_class)
        existing_obj = get_object_or_404(Shares, folio_no = folio_no, class_of_shares=share_class)
        print(existing_obj)
        existing_obj.no_of_shares = float(existing_obj.no_of_shares) + float(no_of_shares)
        existing_obj.save()
        return existing_obj
    except Exception as e:
        print(share_class)
        share_obj = {}
        share_obj['no_of_shares'] = no_of_shares
        share_obj['class_of_shares'] = share_class
        share_obj['folio_no'] = folio_no
        print(share_obj)
        new_obj = Shares.objects.create(**share_obj)
        new_obj.save()
        return new_obj

# Create your views here.
@ms_identity_web.login_required
def home(request):
    sh_form = AddShareholderForm()
    tr_form = AddTransactionForm()
    cp_form = AddcompanyForm()

    args = {}
    args['sh_form'] = sh_form
    args['tr_form'] = tr_form
    args['cp_form'] = cp_form
    return render(request, 'addshares.html', args)
    # return render(request, 'index.html')

@ms_identity_web.login_required
def addshareholder(request):
    form = AddShareholderForm(request.POST)
    if ShareHolder.objects.filter(name = request.POST['name']).all():
        messages.error(request, 'Shareholder name already exists')
        return redirect('/transaction/add')
    form = AddShareholderForm(request.POST)
    if form.is_valid():
        form.save()
        messages.success(request, 'Shareholder added successfully')
        return redirect('/transaction/add')
    for field, errors in form.errors.items():
        for error in errors:
            messages.error(request, error)
    return redirect('/')


@ms_identity_web.login_required
def company(request):
    cp_form = AddcompanyForm()
    args = {}
    args['cp_form'] = cp_form
    return render(request, 'company.html',args)

@ms_identity_web.login_required
def addcompany(request):
    if request.POST:
        if Company.objects.filter(name = request.POST['name']).all():
           messages.error(request, 'company name already exists')
           return redirect('/company')
        form_data = {
        'name': request.POST['name'],
        'address': request.POST['address'],
        'user_log' : request.POST['hid_name'],
        'currency' : request.POST['currency']
        #'event_date': datetime.datetime.strptime(request.POST['event_date'], "%Y-%m-%d"),
        }
        print("Here", form_data) 
        print(request.POST)
        form = Company.objects.create(**form_data)
        if form:
                form.save()
                messages.success(request, 'company added successfully')
                return redirect('/company')
        messages.error(request, 'Error adding transaction')
        return redirect('/')
    for field, errors in form.errors.items():
            print(form.errors)
            for error in errors:
                messages.error(request, error)
                print(error)
    return redirect('/company')

    
    
    

@ms_identity_web.login_required
def addtransaction(request):
    print("Here ",(request.identity_context_data.nonce))

    if request.POST:
        if Transaction.objects.filter(folio_no = request.POST['folio_no']).all() and request.POST['event'] == "Incorporation":
           messages.error(request, 'Shareholder already Incorporated')
           return redirect('/transaction/add') 
        if (not Transaction.objects.filter(folio_no = request.POST['folio_no']).all()) and request.POST['event'] == "Subscription":
           messages.error(request, 'Shareholder First entry should be Incorporation')
           return redirect('/transaction/add')
        form_data = {
            'folio_no': ShareHolder.objects.get(folio_no = request.POST['folio_no']),
            'event': request.POST['event'],
            'no_of_shares': request.POST['no_of_shares'],
            'share_class': request.POST['class_of_share'],
            'nominal_value': request.POST['nominal_value'],
            'consideration': request.POST['consideration'],
            'total': 0,
            'status': 'Active',
            'created_at': datetime.datetime.now(),
            'event_date': datetime.datetime.strptime(request.POST['event_date'], "%Y-%m-%d"),
            'user_log' : request.POST['hid_name']
            # 'class_of_share': request.POST['class_of_share']
            # 'transfer_details': Null
        }
        print("Here", form_data)
        # form = AddTransactionForm(form_data)
        print(request.POST)
        if form_data['event'] in ['Subscription', 'Incorporation']:
            form = Transaction.objects.create(**form_data)
            if form:
                update_shares(form_data['folio_no'], request.POST['class_of_share'], form_data['no_of_shares'])
                form.save()
                messages.success(request, 'Transaction added successfully')
                return redirect('/transaction/add')
            messages.error(request, 'Error adding transaction')
            return redirect('/transaction/add')
        for field, errors in form.errors.items():
            print(form.errors)
            for error in errors:
                messages.error(request, error)
                print(error)
        return redirect('/transaction/add')
    sh_form = AddShareholderForm()
    tr_form = AddTransactionForm()
    args = {}
    args['sh_form'] = sh_form
    args['tr_form'] = tr_form
    return render(request, 'addshares.html', args)

@ms_identity_web.login_required
def transfer(request):   
    if request.POST:
        form_data = request.POST.copy()
        print(request.POST)
        form_data.update({
            'event': 'Transfer'
        })
        form = TransferShareForm(form_data)
        print(form)
        transferer = ShareHolder.objects.get(folio_no = request.POST['transferer'])
        transferee = ShareHolder.objects.get(folio_no = request.POST['transferee'])
        if not transferer == transferee:
            if form.is_valid():
                transferer = ShareHolder.objects.get(folio_no = request.POST['transferer'])
                transferee = ShareHolder.objects.get(folio_no = request.POST['transferee'])
                print(form.cleaned_data)
                try:
                    available_shares = Shares.objects.get(folio_no = transferer, class_of_shares = form.cleaned_data['share_class'])
                    if available_shares.no_of_shares >= form.cleaned_data['no_of_shares']:
                        transfer_data = {
                            'transferer': transferer,
                            'transferee': transferee,
                            'share_class': form.cleaned_data['share_class'],
                            'no_of_shares': form.cleaned_data['no_of_shares'],
                            'nominal_value': 0
                        }
                        print(transfer_data)
                        transfer_details = TransferDetails.objects.create(**transfer_data)
                        if transfer_details:
                            transferer_data = {
                                'folio_no': transferer,
                                'event': form_data['event'],
                                'no_of_shares': -abs(float(form_data['no_of_shares'])),
                                'share_class': form.cleaned_data['share_class'],
                                'nominal_value': 0,
                                'consideration': form_data['consideration'],
                                'total': 0,
                                'status': 'Active',
                                'created_at': '',
                                'event_date': form_data['event_date'],
                                'user_log' : request.POST['hid_name'],
                                'transfer_details': transfer_details
                            }
                            Transaction.objects.create(**transferer_data)
                            update_shares(transferer, transfer_data['share_class'], transferer_data['no_of_shares'])
                            transferee_data = {
                                'folio_no': transferee,
                                'event': form_data['event'],
                                'no_of_shares': form_data['no_of_shares'],
                                'share_class': form.cleaned_data['share_class'],
                                'nominal_value': 0,
                                'consideration': form_data['consideration'],
                                'total': 0,
                                'status': 'Active',
                                'created_at': '',
                                'event_date': form_data['event_date'],
                                'user_log' : request.POST['hid_name'],
                                'transfer_details': transfer_details
                            }
                            Transaction.objects.create(**transferee_data)
                            update_shares(transferee, transfer_data['share_class'], transferee_data['no_of_shares'])
                            messages.success(request, 'Transfer successfull.')

                            return redirect('/transaction/transfer')
                        messages.error(request, 'Error Transferring shares.')
                        return redirect('/transaction/transfer')

                    else:
                        messages.error(request, 'Error Transferring shares. Insufficient Balance.')
                        return redirect('/transaction/transfer')
                except Exception as e:
                    messages.error(request, 'Error Transferring shares. Please check balance.')
                    return redirect('/transaction/transfer')
        else :
            messages.error(request, 'Cannot transfer funds to same shareholder')
            return redirect('/transaction/transfer')

        for field, errors in form.errors.items():
            print(form.errors)
            for error in errors:
                messages.error(request, error)
                print(error)
        return redirect('/transaction/transfer')

    sh_form = AddShareholderForm()
    tr_form = TransferShareForm()
    args = {}
    args['sh_form'] = sh_form
    args['tr_form'] = tr_form
    return render(request, 'transfershares.html', args)

@ms_identity_web.login_required
def convert(request):
    if request.POST:
        print(request.POST)
        shareholder = ShareHolder.objects.get(folio_no = request.POST['folio_no'])
        try:
            share_qty = Shares.objects.get(folio_no = shareholder, class_of_shares = request.POST['share_class'])
            if share_qty.no_of_shares >= sum(int(a) for a in request.POST.getlist('convert_quantity')):
                transaction_data = {
                    'folio_no': shareholder,
                    'event': 'Conversion',
                    'no_of_shares': sum(int(a) for a in request.POST.getlist('convert_quantity')),
                    'share_class': request.POST['share_class'],
                    'nominal_value': 0.01,
                    'consideration': request.POST['consideration'],
                    'total': 0,
                    'status': 'Active',
                    'created_at': datetime.datetime.now(),
                    'user_log' : request.POST['hid_name'],
                    'event_date': datetime.datetime.now()
                }
                transaction = Transaction.objects.create(**transaction_data)
                if transaction:
                    # print(request.POST.getlist('convert_class'))
                    for i, row in enumerate(request.POST.getlist('convert_class')):
                        # print(i, row)
                        convert_data = {
                            'convert_from': request.POST['share_class'],
                            'convert_to': request.POST.getlist('convert_class')[i],
                            'no_of_shares': request.POST.getlist('convert_quantity')[i],
                            'transaction_id': transaction
                        }
                        update_one = update_shares(shareholder, request.POST['share_class'], -abs(float(request.POST.getlist('convert_quantity')[i])))
                        update_two = update_shares(shareholder, request.POST.getlist('convert_class')[i], abs(float(request.POST.getlist('convert_quantity')[i])))
                        if update_one and update_two:
                            ConvertDetails.objects.create(**convert_data)
                    messages.success(request, 'Conversion Successfull')
                    return redirect('/transaction/convert')
                messages.error(request, 'Error while converting shares')
                return redirect('/transaction/convert')
            messages.error(request, 'Insufficient Funds')
        except Exception as e:
            print(e)
            messages.error(request, 'Error occured : No shares Converted')
    sh_form = AddShareholderForm()
    cs_form = ConversionShareForm()
    args = {}
    args['sh_form'] = sh_form
    args['cs_form'] = cs_form
    return render(request, 'convertshares.html', args)

@ms_identity_web.login_required
def transaction(request):
    data = Transaction.objects.all()
    args = {}
    args['data'] = data
    return render(request, 'transactionview.html', args)

@ms_identity_web.login_required
def generate(request):
    sh_data = ShareHolder.objects.all()
    wb = openpyxl.Workbook()
    for data in sh_data:
        ws = wb.create_sheet()
        ws.title = str(data.folio_no) + "("+ data.name +")"
        generate_header(data, ws)
        tr_data = Transaction.objects.filter(folio_no = data.folio_no)
        curr_total = {}
        for row in tr_data:
            # curr_total += row.no_of_shares
            curr_total = generate_row(row, ws, curr_total)
    wb['Sheet'].title='company1'
    generate_frontpage(wb['company1'])
        
    filename = 'company1.l.xlsx'
    wb.save(filename)
    wb.close()
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
  
    filepath = base_dir + '/' + filename
    thefile = filepath
    filename =  os.path.basename(thefile)
    chunk_size = 8192
    response = StreamingHttpResponse(FileWrapper(open(thefile,'rb'),chunk_size),content_type=mimetypes.guess_type(thefile)[0])
    response['Content-Length'] = os.path.getsize(thefile)
    response['Content-Disposition'] = "Attachment;filename=%s" % filename
    print("file downloaded")
    return response