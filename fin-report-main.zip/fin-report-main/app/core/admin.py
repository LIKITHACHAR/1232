from django.contrib import admin

from core.models import (
    Company,
    ShareHolder,
    Shares,
    TransferDetails,
    Transaction,
    ConvertDetails
)

class CompanyAdmin(admin.ModelAdmin):
    ordering = ['company_id']
    list_display = ['company_id', 'name', 'address']
    readonly_fields = ['company_id']
    add_fields = (
        (None, {
            'classes': ('wide',),
            'fields': (
                'name',
                'address'
            )
        })
    )

class ShareHolderAdmin(admin.ModelAdmin):
    ordering = ['folio_no']
    list_display = ['folio_no', 'name', 'address', 'legal_form', 'company']
    readonly_fields = ['folio_no']
    add_fields = (
        (None, {
            'classes': ('wide', ),
            'fields': (
                'name',
                'address',
                'legal_form',
                'company'
            )
        })
    )

class SharesAdmin(admin.ModelAdmin):
    ordering = ['share_id']
    list_display = ['share_id', 'no_of_shares', 'class_of_shares', 'folio_no']
    readonly_fields = ['share_id']
    add_fields = (
        (None, {
            'classes': ('wide', ),
            'fields': (
                'no_of_shares',
                'class_of_shares',
                'folio_no'
            )
        })
    )

class TransferDetailsAdmin(admin.ModelAdmin):
    ordering = ['td_id']
    list_display = ['td_id', 'transferer', 'transferee', 'share_class', 'no_of_shares', 'nominal_value']
    readonly_fields = ['td_id']
    add_fields = (
        (None, {
            'classes': ('wide', ),
            'fields': (
                'transferer',
                'transferee',
                'share_class',
                'no_of_shares',
                'nominal_value'
            )
        })
    )

class ConvertDetailsAdmin(admin.ModelAdmin):
    ordering = ['conversion_id']
    list_display = ['conversion_id', 'convert_from', 'convert_to', 'no_of_shares', 'transaction_id']
    readonly_fields = ['conversion_id']
    add_fields = (
        (None, {
            'classes': ('wide', ),
            'fields': (
                'convert_from',
                'convert_to',
                'no_of_shares',
                'transaction_id'
            )
        })
    )

class TransactionAdmin(admin.ModelAdmin):
    ordering = ['transaction_id']
    list_display = ['transaction_id', 'folio_no', 'event', 'no_of_shares', 'share_class', 'nominal_value', 'consideration', 'total', 'status', 'created_at', 'event_date', 'transfer_details']
    readonly_fields = ['transaction_id']
    add_fields = (
        (None, {
            'classes': ('wide', ),
            'fields': (
                'folio_no',
                'event',
                'no_of_shares',
                'share_class',
                'nominal_value',
                'consideration',
                'total',
                'status',
                'created_at',
                'event_date',
                'transfer_details'
            )
        })
    )

admin.site.register(Company, CompanyAdmin)
admin.site.register(ShareHolder, ShareHolderAdmin)
admin.site.register(Shares, SharesAdmin)
admin.site.register(TransferDetails, TransferDetailsAdmin)
admin.site.register(Transaction, TransactionAdmin)
admin.site.register(ConvertDetails, ConvertDetailsAdmin)
