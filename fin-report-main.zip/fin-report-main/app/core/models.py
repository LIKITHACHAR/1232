from django.db import models
from django.utils import timezone

event_choices = (
    ('Incorporation', 'Incorporation'),
    ('Subscription', 'Subscription'),
)

class Company(models.Model):
    company_id = models.BigAutoField(primary_key=True)
    name = models.CharField(max_length=255)
    address = models.TextField(blank=True)
    user_log = models.CharField(max_length=255, null=True)
    currency = models.CharField(max_length=255, null=True)

class ShareHolder(models.Model):
    folio_no = models.BigAutoField(primary_key=True)
    name = models.CharField(max_length=255)
    address = models.TextField(blank=True)
    legal_form = models.TextField(blank=True)
    company = models.ForeignKey(Company, on_delete=models.CASCADE, to_field="company_id", null=True)

    def __str__(self):
        return self.name

class Shares(models.Model):
    share_id = models.BigAutoField(primary_key=True)
    no_of_shares = models.DecimalField(max_digits=15, decimal_places=2)
    class_of_shares = models.TextField(max_length=255)
    folio_no = models.ForeignKey(ShareHolder, on_delete=models.DO_NOTHING, to_field="folio_no")

class TransferDetails(models.Model):
    td_id = models.BigAutoField(primary_key=True)
    transferer = models.ForeignKey(ShareHolder, related_name="transfered_from", on_delete=models.DO_NOTHING)
    transferee = models.ForeignKey(ShareHolder, related_name="transfered_to", on_delete=models.DO_NOTHING)
    share_class = models.CharField(max_length=255)
    no_of_shares = models.DecimalField(max_digits=15, decimal_places=2)
    nominal_value = models.DecimalField(max_digits=15, decimal_places=2, default=0.0)

class Transaction(models.Model):
    transaction_id = models.BigAutoField(primary_key=True)
    folio_no = models.ForeignKey(ShareHolder, on_delete=models.CASCADE, to_field="folio_no")
    event = models.CharField(max_length=255, choices=event_choices, default='A')
    no_of_shares = models.DecimalField(max_digits=15, decimal_places=2)
    share_class = models.CharField(max_length=255, default="Ordinary Shares")
    nominal_value = models.DecimalField(max_digits=15, decimal_places=2, default=0.01)
    consideration = models.DecimalField(max_digits=15, decimal_places=4)
    total = models.DecimalField(max_digits=15, decimal_places=2)
    status = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    event_date = models.DateTimeField()
    transfer_details = models.ForeignKey(TransferDetails, null=True, on_delete=models.DO_NOTHING)
    user_log = models.CharField(max_length=255, null=True)
    # convert_details = models.ForeignKey(ConvertDetails, null=True, on_delete=models.DO_NOTHING)

class ConvertDetails(models.Model):
    conversion_id = models.BigAutoField(primary_key=True)
    convert_from = models.CharField(max_length=255)
    convert_to = models.CharField(max_length=255)
    no_of_shares = models.DecimalField(max_digits=15, decimal_places=2)
    transaction_id = models.ForeignKey(Transaction, null=True, on_delete=models.CASCADE, related_name="convert")
    