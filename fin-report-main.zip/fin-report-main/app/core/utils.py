import openpyxl
from openpyxl.styles import Alignment
from openpyxl.styles import Border ,Side ,Font
from datetime import timezone

def gen_row_incorporation(data, total_shares):
    # d = []
    # d.append(data.created_at.strftime('%d-%m-%Y'))
    # d.append(data.event)
    # d.append(data.no_of_shares)
    # d.append(total)
    # d.append('signature')
    if data.share_class in total_shares:
        total_shares[data.share_class] += float(data.no_of_shares)
    else:
        total_shares[data.share_class] = float(data.no_of_shares)
    d = []
    d.append(data.event_date.astimezone(timezone.utc).strftime('%B %d, %Y'))
    d.append(f"Incorporation of the company")
    d.append(f"Subscription of {str(int(data.no_of_shares))} shares/{data.share_class} shares with a nominal value of EUR {str(data.nominal_value)} each")
    # d.append(str(abs(int(data.no_of_shares))) + " shares")
    tot_str = ""
    for key in total_shares:
        tot_str += f"\n{int(total_shares[key])} class {key} shares"
    d.append(tot_str)
    d.append('')
    return d, total_shares



def gen_row_subscription(data, total_shares):
    if data.share_class in total_shares:
        total_shares[data.share_class] += float(data.no_of_shares)
    else:
        total_shares[data.share_class] = float(data.no_of_shares)
    d = []
    d.append(data.event_date.astimezone(timezone.utc).strftime('%B %d, %Y'))
    d.append(f"Increase of the share capital of the Company")
    d.append(f"Subscription of {str(int(data.no_of_shares))} shares/{data.share_class} shares with a nominal value of EUR {str(data.nominal_value)} each")
    tot_str = ""
    for key in total_shares:
        tot_str += f"\n{int(total_shares[key])} class {key} shares"
    d.append(tot_str)
    d.append('')
    return d, total_shares

def gen_row_transfer(data, total_shares):
    if data.folio_no == data.transfer_details.transferer:
        if data.share_class in total_shares:
            total_shares[data.share_class] += float(data.no_of_shares)
        else:
            total_shares[data.share_class] = float(data.no_of_shares)
        d = []
        d.append(data.event_date.strftime('%B %d, %Y'))
        d.append(f"Transfer of shares to {data.transfer_details.transferee}")
        d.append(f"Transfer of {str(abs(int(data.no_of_shares)))} {data.share_class} shares, with a nominal value of EUR {str(data.nominal_value)} each")
        tot_str = ""
        for key in total_shares:
            tot_str += f"\n{total_shares[key]} shares/{key} shares"
        d.append(tot_str)
        d.append('')
        return d, total_shares
    if data.share_class in total_shares:
        total_shares[data.share_class] += float(data.no_of_shares)
    else:
        total_shares[data.share_class] = float(data.no_of_shares)
    d = []
    d.append(data.event_date.astimezone(timezone.utc).strftime('%B %d, %Y'))
    d.append(f"Acquisition of shares from {data.transfer_details.transferer}")
    d.append(f"Acquisition of {str(int(data.no_of_shares))} {data.share_class} shares, with a nominal value of EUR {str(data.nominal_value)} each")
    tot_str = ""
    for key in total_shares:
        tot_str += f"\n{int(total_shares[key])} class {key} shares"
    d.append(tot_str)
    d.append('')
    return d, total_shares

def gen_row_conversion(data, total_shares):
    exist_share = []
    new_share = []
    if data.share_class in total_shares:
        exist_share.append(data.share_class)
        total_shares[data.share_class] -= float(data.no_of_shares)
    else:
        new_share.append(data.share_class)
        total_shares[data.share_class] = float(data.no_of_shares)
    temp_str = f"Reclassification of existing {str(int(data.no_of_shares))} {data.share_class} shares into: \n"
    for row in data.convert.all():
        temp_str += f"{str(int(row.no_of_shares))} class {str(row.convert_to)} shares\n"
        if row.convert_to in total_shares:
            exist_share.append(row.convert_to)
            total_shares[row.convert_to] += float(row.no_of_shares)
        else:
            new_share.append(row.convert_to)
            total_shares[row.convert_to] = float(row.no_of_shares)
    temp_str += "\nwith a nominal value of EUR 0.01 each"
    d = []
    d.append(data.event_date.astimezone(timezone.utc).strftime('%B %d, %Y'))
    B_str = "Extra ordinary general meeting approving:\n"
    if new_share:
        B_str += "\nCreation of new classes of shares into "
        for share in new_share:
            B_str += f"class {share} shares, "
        B_str = B_str[:-2]
    if exist_share:
        B_str += f"\nReclassification of existing {data.share_class} shares"
        # for share in exist_share:
        #     B_str += f"{share} shares\n"
    d.append(B_str)
    d.append(temp_str)
    tot_str = ""
    for key in total_shares:
        tot_str += f"\n{int(total_shares[key])} class {key} shares"
    d.append(tot_str)
    d.append('')
    return d, total_shares


def generate_header(sh, ws):
    # print(sh.folio_no)
    worksheet = ws
    border = Border(left=Side(style='thin'),
                top=Side(style='thin'),
                right=Side(style='thin'),
                bottom=Side(style='thin'))
    font = Font(bold=True)
    line1 = ["Shareholder:", sh.name]
    line2 = ["Legal form:", sh.legal_form]
    line3 = ["Address:", sh.address]
    line4 = []
    line5 = ["Date","Subscription/acquisition","Shares transferred/ converted/ subscribed","Total number of shares","Signature"]

    merged_range0 = "B1:E1"
    merged_range1 = "B2:E2"
    merged_range2 = "B3:E3"
    merged_range3 = "A4:E4"

    # Change height of row A1
    worksheet.row_dimensions[1].height = 30
    worksheet.row_dimensions[2].height = 30
    worksheet.row_dimensions[3].height = 30
    worksheet.row_dimensions[4].height = 15
    worksheet.row_dimensions[5].height = 35
    # Change width of column B
    worksheet.column_dimensions["A"].width = 16
    worksheet.column_dimensions["B"].width = 50
    worksheet.column_dimensions["C"].width = 30
    worksheet.column_dimensions["D"].width = 25
    worksheet.column_dimensions["E"].width = 25

    # Write data to cells
    worksheet.append(line1)
    worksheet.append(line2)
    worksheet.append(line3)
    worksheet.append(line4)
    worksheet.append(line5)

    # Merge cells and set alignment
    worksheet.merge_cells(merged_range0)
    worksheet.merge_cells(merged_range1)
    worksheet.merge_cells(merged_range2)
    worksheet.merge_cells(merged_range3)
    worksheet['A1'].alignment = Alignment(horizontal ='left', vertical='center')
    worksheet['A2'].alignment = Alignment(horizontal ='left', vertical='center')
    worksheet['A3'].alignment = Alignment(horizontal ='left', vertical='center')
    worksheet['B1'].alignment = Alignment(horizontal ='left', vertical='center')
    worksheet['B2'].alignment = Alignment(horizontal ='left', vertical='center')
    worksheet['B3'].alignment = Alignment(horizontal ='left', vertical='center')
    worksheet['C5'].alignment = Alignment(horizontal ='center', vertical='center',wrap_text=True)
    worksheet['D5'].alignment = Alignment(horizontal ='center', vertical='center',wrap_text=True)
    worksheet['E5'].alignment = Alignment(horizontal ='center', vertical='center')
    worksheet['A5'].alignment = Alignment(horizontal ='center', vertical='center')
    worksheet['B5'].alignment = Alignment(horizontal ='center', vertical='center')

    #font
    worksheet['A1'].font = font
    worksheet['A2'].font = font
    worksheet['A3'].font = font
    worksheet['A5'].font = font
    worksheet['B5'].font = font
    worksheet['B1'].font = font
    worksheet['C5'].font = font
    worksheet['D5'].font = font
    worksheet['E5'].font = font
    #border

    worksheet['A5'].border = border
    worksheet['B5'].border = border
    worksheet['C5'].border = border
    worksheet['D5'].border = border
    worksheet['E5'].border = border
    worksheet['A1'].border = border
    worksheet['B1'].border = border
    worksheet['A2'].border = border
    worksheet['B2'].border = border
    worksheet['A3'].border = border
    worksheet['B3'].border = border
    worksheet['c1'].border = border
    worksheet['c2'].border = border
    worksheet['c3'].border = border
    worksheet['D1'].border = border
    worksheet['D2'].border = border
    worksheet['D3'].border = border
    worksheet['E1'].border = border
    worksheet['E2'].border = border
    worksheet['E3'].border = border

def generate_frontpage(ws):
    worksheet = ws
    data = [
        ['company1',' ',' '],
        ['Electronicity, Bengaluru - 560100',' ',' '],
        ['Registered office: Electronicity, Bengaluru - 560100 ',' ',' '],
        ['R.C.S. 1 : B 11123',' ',' '],
        ['Share capital:EUR 12345',' ',' '],
        ['Amendments to the articles of association of the Company', ' ', ' ', ],
        ['Date: ', ' ', 'Date: ', ],
        ['Notary:', ' ', 'Notary: ', ],
        ['Place:', ' ', 'Place: ', ],
        [' ', ' ', ' ', ],
        ['Date: ', ' ', 'Date: ', ],
        ['Notary:', ' ', 'Notary: ', ],
        ['Place:', ' ', 'Place: ', ],
        [' ', ' ', ' ', ],['Date: ', ' ', 'Date: ', ],
        ['Notary:', ' ', 'Notary: ', ],
        ['Place:', ' ', 'Place: ', ],
        [' ', ' ', ' ', ],['Date: ', ' ', 'Date: ', ],
        ['Notary:', ' ', 'Notary: ', ],
        ['Place:', ' ', 'Place: ', ],
        [' ', ' ', ' ', ],
    ]

    for d in data:
        rwstart = int(worksheet.max_row)+1

        for i in range(1,len(d)+1):
            if rwstart <= 6:  # Check if in the first 6 rows (merged)
                alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
            #elif rwstart == 7:
             #   worksheet.cell(row=rwstart, column=i).border = Border(left=Side(style='thin'),top=Side(style='thin'),right=Side(style='thin'),bottom=Side(style='thin'))
                #worksheet.cell(row=7, column=1).border = Border(left=Side(style='thin'),top=Side(style='thin'),right=Side(style='thin'),bottom=Side(style='thin'))
            else:
                alignment = Alignment(horizontal='left', vertical='center')
            worksheet.cell(row=rwstart, column=i).value = d[i-1]
            worksheet.cell(row=rwstart, column=i).alignment = alignment
        rwstart += 1


            # ws.cell(row=rwstart, column=i).alignment = Alignment(vertical='middle')
    worksheet.column_dimensions["A"].width = 70
    worksheet.column_dimensions["C"].width = 20

    for r in range (1 ,7):
        merged_range = f"A{r}:C{r}"
        worksheet.merge_cells(merged_range)

        for n in range (1,23):
            if n == 7:
                worksheet[f"C{n}"].border = Border()
            else:
                worksheet[f"C{n}"].border = Border(right=Side(style='thin'))

        for n in range (1,23):
            worksheet[f"A{n}"].border = Border(left=Side(style='thin'))

        worksheet['A7'].border = Border(left=Side(style='thin'),top=Side(style='thin'),right=Side(style='thin'),bottom=Side(style='thin'))
        worksheet['B7'].border = Border(left=Side(style='thin'),top=Side(style='thin'),right=Side(style='thin'),bottom=Side(style='thin'))
        worksheet['C7'].border = Border(left=Side(style='thin'),top=Side(style='thin'),right=Side(style='thin'),bottom=Side(style='thin'))
        worksheet['A1'].border = Border(top=Side(style='thin'),left=Side(style='thin'))
        worksheet['B1'].border = Border(top=Side(style='thin'))
        worksheet['C1'].border = Border(top=Side(style='thin'),right=Side(style='thin'))
        worksheet['A23'].border = Border( bottom=Side(style='thin'), left=Side(style='thin'))
        worksheet['B23'].border = Border( bottom=Side(style='thin'))
        worksheet['C23'].border = Border( bottom=Side(style='thin'), right=Side(style='thin'))

        mrange = "A7:C7"
        worksheet.merge_cells(mrange)

def generate_row(data, ws, total):
    rwstart = int(ws.max_row) + 1
    print('Start',rwstart)
    rwend = rwstart + 10

    if data.event == 'Incorporation':
        d, total = gen_row_incorporation(data, total)
    elif data.event == 'Subscription':
        d, total = gen_row_subscription(data, total)
    elif data.event == 'Transfer':
        d, total = gen_row_transfer(data, total)
    elif data.event == 'Conversion':
        d, total = gen_row_conversion(data, total)
    else:
        d = []
        d.append(data.created_at.strftime('%d-%m-%Y'))
        d.append(data.event)
        d.append(data.no_of_shares)
        d.append(total)
        d.append('signature')
    for i in range(1, int(ws.max_column)+1):
        # print(i)
        ws.merge_cells(start_row=rwstart, start_column=i, end_row=rwend, end_column=i)
        ws.cell(row=rwstart, column=i).value = d[i-1]
        ws.cell(row=rwstart, column=i).alignment = Alignment(horizontal='center',vertical='center', wrapText=True)
        ws.cell(row=rwend, column=i).border = Border(bottom=Side(style='thin'))
        for i in range(1, int(ws.max_column)+1):
            for j in range(rwstart, rwend+1):
                ws.cell(row=j, column=i).border = Border(right=Side(style='thin'), left=Side(style='thin'), bottom=Side(style='thin'))
    return total